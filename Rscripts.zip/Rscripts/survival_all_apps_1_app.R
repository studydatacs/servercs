library(survival)
library(survminer)
library(dplyr)
library(svglite)


# app = "phpmyadmin"
# app="dokuwiki"
# app="opencart"
# app="phpbb"
# app="phppgadmin"
# app="mediawiki"
# app="prestashop"
# app="vanilla"
# app="dolibarr"
# app="roundcubemail"
app="openemr"
# app="kanboard"

dat = read.csv(file = paste("D:/dwork/serversmells/survival/data/18/", app ,"_ss_evol_18.csv", sep=""), header = TRUE, sep=";", na.strings = "NULL")

#dat=filter(dat1, ruleset == "Design Rules" | ruleset == "Code Size Rules")

#teste
#dat$censored1 = ifelse(dat$censored == 0, 1, 0)
#surv_object = Surv(time = dat$diff,   event = dat$censored)

#dat$scope = ifelse(dat$ruleset == "Design Rules", "Scattered Smells", "Localized Smells")



#tail(dat)

#database managers, wikis, forums, shopping/stores

surv_object = Surv(time = dat$diff,   event = dat$censored)

#fit1 = survfit(surv_object ~ 1, data = dat)
#fit1 = survfit(surv_object ~ scope, data = dat)
#fit1 = survfit(surv_object ~ app, data = dat)
#fit1 = survfit(surv_object ~ domain, data = dat)
fit1 = survfit(surv_object ~ rule, data = dat)

## ver a mediana
########print(fit1)
print(summary(fit1)$table)

#### restricted mean survival (rmean)

ggsurvplot(fit1, data = dat, pval = TRUE, title = "All apps" , xlab="Time (days)", surv.median.line = "hv", font.legend=14)

## p value
######test=surv_pvalue(fit1, dat)
######print(test$pval)


ggsave(file=paste0("D:/dwork/serversmells/survival/graficos/output_survival_all_apps/bysmell_", app ,".svg"), width = 10, height = 6.5)