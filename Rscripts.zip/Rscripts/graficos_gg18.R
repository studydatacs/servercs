library(ggplot2)
library(dplyr)
library(ggrepel)

#app

#### graficos de linhas

app="phpmyadmin"
app="opencart"
app="phpbb"
app="dokuwiki"
app="mediawiki"
app="prestashop"
app="phppgadmin"
app="vanilla"
app="dolibarr"
# app="roundcubemail"
#app="openemr"
# app="kanboard"


#path
#path= "D:/dwork/serversmells/survival/graficos/"
path= "D:/dwork/serversmells/survival/data/18/"

file= paste(path ,app , "_ss_evol_18.csv" , sep="")

data =  read.csv(file,header=TRUE,sep=";")
data = data[nrow(data):1,]   #reverse

data1= data.frame(id=data$id, rule=data$rule, date1=as.Date(data$date_init), date2=as.Date(data$date_end), censored=data$censored)
data1$idnum <- seq.int(nrow(data1))


head(data1)
#datasub = subset(dataline, cs.by.klloc.var <= -0.5)

#my_colors <- c("red", "brown", "green", "blue", "darkblue", "purple")
my_colors =hcl(seq(15,375,length=18+1)[1:18], 100, 65)

names(my_colors) = c("CyclomaticComplexity", 
"NPathComplexity",
"ExcessiveMethodLength",
"ExcessiveClassLength",
"ExcessiveParameterList",
"ExcessivePublicCount",
"TooManyFields",
"TooManyMethods",
"TooManyPublicMethods",
"ExcessiveClassComplexity",
"NumberOfChildren",
"DepthOfInheritance",
"CouplingBetweenObjects",
"DevelopmentCodeFragment",
"UnusedPrivateField",
"UnusedLocalVariable",
"UnusedPrivateMethod",
"UnusedFormalParameter")

my_scale <- scale_colour_manual(name = "rule", values = my_colors) 

ggplot(data=data1) + 
  geom_segment(aes(x = date1 , y = idnum, 
                   xend = date2, yend =idnum,
                   colour=rule
                   )) +
  scale_x_date(name ="Date (years)",  date_minor_breaks = "1 year", date_breaks = "1 year", date_labels = format("%Y")) +
  scale_y_continuous(name ="CS#") +
  theme(
    #legend.position="top",
    legend.position="none",
    legend.margin=margin(c(0,0,-0.5,0), unit="line"),
    text = element_text(size = 20),
    axis.text.x = element_text(angle = 30)
    ) +
  guides(color=guide_legend(ncol=3))+
  my_scale +
  ggtitle(app)
#+
#  geom_text_repel(data = c(), mapping = aes(label = version))


ggsave(file=paste0("D:/dwork/serversmells/survival/graficos/output_years/",app,".svg"), width = 10, height = 6.5)



#########################################################
