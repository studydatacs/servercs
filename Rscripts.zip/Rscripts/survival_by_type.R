library(survival)
library(survminer)
library(dplyr)
library(svglite)


# app = "phpmyadmin"
# app="dokuwiki"
# app="opencart"
# app="phpbb"
# app="phppgadmin"
# app="mediawiki"
# app="prestashop"
# app="vanilla"
# app="dolibarr";
# app="roundcubemail";
app="openemr";
# app="kanboard";

dat1 = read.csv(file = paste("D:/dwork/serversmells/survival/data/6/", app, "_ss_evol_6.csv", sep=""), header = TRUE, sep=";", na.strings = "NULL")

dat=filter(dat1, ruleset == "Design Rules" | ruleset == "Code Size Rules")

#teste
#dat$censored1 = ifelse(dat$censored == 0, 1, 0)
#surv_object = Surv(time = dat$diff,   event = dat$censored)

surv_object = Surv(time = dat$diff,   event = dat$censored)

dat$scope = ifelse(dat$ruleset == "Design Rules", "Scattered Smells", "Localized Smells")

fit1 = survfit(surv_object ~ scope, data = dat)

## ver a mediana
print(fit1)
print(summary(fit1)$table)

#### restricted mean survival (rmean)

ggsurvplot(fit1, data = dat, pval = TRUE, title = app , xlab="Time (days)", legend.title="Type", font.legend=20, surv.median.line = "hv", legend = "none")
#ggsurvplot(fit1, data = dat, pval = TRUE, title = app , xlab="Time (days)", legend.title="", font.legend=20, surv.median.line = "hv")

ggsave(file=paste0("D:/dwork/serversmells/survival/graficos/output_survival_type/",app,".svg"), width = 10, height = 6.5)


## p value
test=surv_pvalue(fit1, dat)
print(test$pval)
##print(test)
##summary(test)



#ggsave(file=paste0("D:/dwork/serversmells/survival/graficos/output_survival_type/jpg/",app,".jpg"), width = 10, height= 6.5)
#ggsave(file=paste0("D:/dwork/serversmells/survival/graficos/output_survival_type/png/",app,".png"), width = 10, height = 6.5)
#ggsave(file=paste0("D:/dwork/serversmells/survival/graficos/output_survival_type/svg/",app,".svg"), width = 10, height = 6.5)

#ggsave(file=paste0("D:/dwork/serversmells/survival/graficos/output_survival_type/",app,".png"), width = 10, height = 6.5, dpi = 300, units = "in", device='png')
#par(mfrow=c(1, 2))
#boxplot(which(dat$ruleset == "Design Rules"), main="Design Rules", sub=paste("Outlier rows: ", boxplot.stats(dat$ruleset)$out))

#boxplot(which(dat$ruleset == "Code Size Rules"), main="Code Size Rules", sub=paste("Outlier rows: ", boxplot.stats(dat$ruleset)$out))
