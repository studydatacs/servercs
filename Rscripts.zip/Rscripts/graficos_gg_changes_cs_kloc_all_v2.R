library(ggplot2)
library(reshape2)
library(dplyr)
library(ggrepel)

#app
app = "phpmyadmin"
app="dokuwiki"
app="opencart"
app="phpbb"
app="phppgadmin"
app="mediawiki"
app="prestashop"
app="vanilla"
app="dolibarr"
# app="roundcubemail"
app="openemr"
# app="kanboard"

#grap with var of cs and kloc
#output 
outputdir = "D:/dwork/serversmells/survival/graficos/output_changes_cs_kloc_all/"

#path
path= "D:/dwork/serversmells/resume/abs/"
file= paste(path ,"resume_", app , ".csv" , sep="")
data =  read.csv(file,header=TRUE,sep=";")



pathm= "D:/dwork/serversmells/resume/loc/"
filem= paste(pathm , app , "_loc.csv" , sep="")
datam =  read.csv(filem,header=TRUE,sep=";")


# dataline=data.frame(version=data$Version, date=as.Date(data$Date),
#                     totalcs=data$CouplingBetweenObjects + data$CouplingBetweenObjects + 
#                       data$ExcessiveClassLength + data$ExcessiveMethodLength +
#                       data$ExcessiveParameterList + data$NumberOfChildren)


dataline=data.frame(version=data$Version, date=as.Date(data$Date), totalcs=rowSums(data[, 4:21]) )


dataline$versionm = datam$Version
dataline$lloc = datam$Logical_Lines_of_Code_.LLOC.


# dataline$cs.by.klloc =   dataline$totalcs * 1000 / dataline$lloc
# dataline$cs.by.klloc.var= (dataline$cs.by.klloc - lag(dataline$cs.by.klloc) ) / lag(dataline$cs.by.klloc)
# dataline[1, "cs.by.klloc.var"]=0

dataline$cs.var= (dataline$totalcs - lag(dataline$totalcs) ) / lag(dataline$totalcs)
dataline[1, "cs.var"]=0

dataline$lloc.var= (dataline$lloc - lag(dataline$lloc) ) / lag(dataline$lloc)
dataline[1, "lloc.var"]=0


dataline
#print (dataline, n=200)
#View(dataline[1:200,])

p = ggplot(data=dataline, aes(x=date,y=cs.var)) + 
  geom_hline(yintercept = 0.5, color = "yellow", size=1) +
  geom_hline(yintercept = 1, color = "red", size=1) +
  geom_hline(yintercept = -0.5, color = "green", size=1) +
  geom_line(size= 1) +
  #geom_line(aes(x=date,y=lloc.var, group = 1, color="red")) +
  ###scale_x_date( name="data") +
  scale_x_date(name ="Date (years)",  date_minor_breaks = "1 year", date_breaks = "1 year", date_labels = format("%Y")) +
  theme(axis.text.x = element_text(angle = 90), text = element_text(size = 24)) +
  #  scale_y_continuous(name ="var of cs", labels = scales::percent) +
  scale_y_continuous(name ="rate of change", labels = scales::percent) +
  ggtitle(app) +
  geom_line(aes(x=date,y=lloc.var), color="steelblue1", linetype="dashed", size=1) 

# +
#   scale_linetype_manual(
#     values = c(1, 3), # play with the numbers to get the correct styling
#     name = "My linetype legend"
#   )


datasup=data = subset(dataline, cs.var > 0.25)

if (nrow(datasup) >0 ){
  p = p + geom_point(data=datasup) +
  geom_text_repel(data = datasup, mapping = aes(label = version), size=6)
}

datasub=data = subset(dataline, cs.var <= -0.25)

if (nrow(datasub) >0 ){
  p = p +
    geom_point(data=datasub) +
    geom_text_repel(data = datasub, mapping = aes(label = version), size=6)
}

p


  

# 
#dataline2 = dataline %>% filter(diff > 0)
dataspots = dataline %>% filter(cs.var >0.5)
dataspots

write.csv(dataline, paste0(outputdir, app, ".csv"))
write.csv(dataspots, paste0(outputdir, app, "_spots.csv"))

#ggsave(file=paste0(outputdir,app,".jpg"), width=10, height=6.5)
ggsave(file=paste0(outputdir,app,".svg"), width=10, height=6.5)
