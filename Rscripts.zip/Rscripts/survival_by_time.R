library(survival)
library(survminer)
library(dplyr)
library(svglite)

# app = "phpmyadmin"
# app="dokuwiki"
# app="opencart"
# app="phpbb"
# app="phppgadmin"
# app="mediawiki"
# app="prestashop"
# app="vanilla"
# app="dolibarr"
# app="roundcubemail"
app="openemr"
# app="kanboard"

print(app)

versions=read.csv(file=paste ("D:/dwork/serversmells/survival/data/versions/", app, "_version.csv", sep=""), header = TRUE, sep=";", na.strings = "NULL")
  
line1=head(versions, 1)
date1=as.Date(line1$date)
linen=tail(versions, 1)
daten=as.Date(linen$date)
diffdays = daten-date1
middays=diffdays /2
mid1 = date1 + middays

date1
daten
middays
mid1

print (paste(date1, daten, "entre: ", middays, "mid:", mid1, " " ))

dat = read.csv(file=paste ("D:/dwork/serversmells/survival/data/18/", app, "_ss_evol_18.csv", sep=""), header = TRUE, sep=";", na.strings = "NULL")

dat$timeframe = ifelse(as.Date(dat$date_init) > mid1, 2, 1)

##dat[,15:21]
#head(dat[,15:21])
#dat$censored = ifelse (dat$version_end == "", 0, 1)
#head(dat[,15:21])

dat$diff_timeframe = ifelse (dat$diff > middays , middays, dat$diff)
dat$censored_timeframe = ifelse (dat$timeframe == 2 , dat$censored, ifelse(dat$diff > middays, 0, 1))

#tail(dat[,15:23], 50)

surv_object = Surv(time = dat$diff_timeframe,   event = dat$censored_timeframe)

fit1 = survfit(surv_object ~ timeframe, data = dat)
#fit1 = survfit(surv_object ~ 1, data = dat)

## ver a mediana
print(fit1)
print(summary(fit1)$table)

ggsurvplot(fit1, data = dat, pval = TRUE, title = app , xlab="Time (days)", legend.title="", font.legend=20, surv.median.line = "hv", legend = "none")
#ggsurvplot(fit1, data = dat, pval = TRUE, title = app, xlab="Time (days)", font.legend=14)

#diff1 = survdiff(surv_object ~ timeframe, data = dat)
#diff1

test=surv_pvalue(fit1, dat)
print(test$pval)


ggsave(file=paste0("D:/dwork/serversmells/survival/graficos/output_survival_time/",app,".svg"), width = 10, height = 6.5)

mid1
