library(ggplot2)
library(reshape2)
#library(viridis)

#app
# app="phpmyadmin"
# app="opencart";
# app="phpbb";
# app="dokuwiki";
# app="mediawiki";
# app="prestashop";
# app="phppgadmin";
# app="vanilla";
app="dolibarr";
# app="roundcubemail";
#app="openemr";
# app="kanboard";

#path  ## abs or density
#path= "D:/dwork/serversmells/resume/density/"
#file= paste(path ,"resume_", app , "_density.csv" , sep="")

path= "D:/dwork/serversmells/resume/abs/"
file= paste(path ,"resume_", app , ".csv" , sep="")

data =  read.csv(file,header=TRUE,sep=";")


# data1= data.frame(Version=data$Version, #date=as.Date(data$Date),
#                   CouplingBetweenObjects=data$CouplingBetweenObjects, DepthOfInheritance=data$DepthOfInheritance,
#                   ExcessiveClassLength=data$ExcessiveClassLength, ExcessiveMethodLength=data$ExcessiveMethodLength,
#                   ExcessiveParameterList=data$ExcessiveParameterList, NumberOfChildren=data$NumberOfChildren)

data1= data.frame(Version=data$Version, #date=as.Date(data$Date),
CyclomaticComplexity=data$CyclomaticComplexity, 
NPathComplexity=data$NPathComplexity ,
ExcessiveMethodLength=data$ExcessiveMethodLength ,
ExcessiveClassLength=data$ExcessiveClassLength ,
ExcessiveParameterList=data$ExcessiveParameterList ,
ExcessivePublicCount=data$ExcessivePublicCount ,
TooManyFields=data$TooManyFields ,
TooManyMethods=data$TooManyMethods ,
TooManyPublicMethods=data$TooManyPublicMethods ,
ExcessiveClassComplexity=data$ExcessiveClassComplexity ,
NumberOfChildren=data$NumberOfChildren ,
DepthOfInheritance=data$DepthOfInheritance ,
CouplingBetweenObjects=data$CouplingBetweenObjects ,
DevelopmentCodeFragment=data$DevelopmentCodeFragment ,
UnusedPrivateField=data$UnusedPrivateField ,
UnusedLocalVariable=data$UnusedLocalVariable ,
UnusedPrivateMethod=data$UnusedPrivateMethod ,
UnusedFormalParameter=data$UnusedFormalParameter)


#convert data frame from a "wide" format to a "long" format
data2 = melt(data1, Version = c("Version"))

data2$Version <- factor(data2$Version, levels=unique(data2$Version))

ggplot(data2, aes(fill=variable, y=value, x=Version)) +   #x=reorder(data2$Version, )
  geom_bar( position="stack", stat="identity") +   #position="dodge",, color="black"
  #scale_x_discrete(limits=Genes,breaks=Genes[seq(1,length(Genes),by=2)])+
  scale_x_discrete( name="Version", 
                    breaks=data2$Version[seq(1,length(unique(data2$Version)),by=5)] , 
                    labels=data2$Version[seq(1,length(unique(data2$Version)),by=5)]) +
  theme(axis.text.x = element_text(angle = 90)) +
    scale_y_continuous(name ="CS#") +
    theme(
       #legend.position="top",
       legend.position = "none",
       legend.margin=margin(c(0,0,-0.5,0), unit="line"), text = element_text(size = 20) ) +  #20
    guides(color=guide_legend(ncol=3))+
    ggtitle(app)



ggsave(file=paste0("D:/dwork/serversmells/survival/graficos/output_stacked_all_sem_legenda/",app,".svg"), width = 10, height = 6.5)



