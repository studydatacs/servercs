library(zoo)
library(xts)
#library(tsibble)
library(tseries)
library(ggplot2)
library(smooth)
library(strucchange)
library(ggrepel)
library(reshape2)


apps=c("phpmyadmin", "dokuwiki", "opencart", "phpbb", 
       "phppgadmin","mediawiki", "prestashop","vanilla",
       "dolibarr", "roundcubemail", "openemr", "kanboard")
#app
app="phpmyadmin"
app="dokuwiki";
app="opencart";
app="phpbb";
app="phppgadmin";
app="mediawiki";
app="prestashop";
app="vanilla";
app="dolibarr";
app="roundcubemail";
app="openemr";
app="kanboard";

output_dir="D:/dwork/serversmells/analysis/evolutionCSseparate/"

#path  ## abs or density
# path= "D:/dwork/serversmells/resume/abs/"
# file= paste(path ,"resume_", app , ".csv" , sep="")

path= "D:/dwork/serversmells/resume/density/"
file= paste(path ,"resume_", app , "_density.csv" , sep="")

dataCS =  read.csv(file,header=TRUE,sep=";")


# cs = cbind.data.frame(date=as.Date(dataCS$Date, "%Y-%m-%d"),
#                       totalCS = rowSums(dataCS[, 4:21] ),
#                       meanCS =  rowMeans(dataCS[, 4:21] )
# )

d = data.frame(dataCS[, 4:21])
d$Date= as.Date(dataCS$Date)

d <- melt(d, id.vars="Date")


# Everything on the same plot
ggplot(d, aes(Date,value, col=variable)) + geom_line(size=1.2) +
  labs(x = "Date (years)", y = "CS density") +
  scale_x_date(date_breaks = "1 years",date_labels = "%y")+
  ggtitle(app)+
  theme(
    #legend.position="right",
    legend.position = "none",
    legend.margin=margin(c(0,0,-0.5,0), unit="line"), text = element_text(size = 16)
  )+
  #geom_label_repel(aes(label = variable),  nudge_x = 1,na.rm = TRUE)
  geom_text(data = filter(d, Date == max(Date)),
            aes(label = variable),
            hjust = 0, nudge_x = 0.1)+
  # Allow labels to bleed past the canvas boundaries
  coord_cartesian(clip = 'off') +
  # Remove legend & adjust margins to give more space for labels
  # Remember, the margins are t-r-b-l
  theme(legend.position = 'none',
        plot.margin = margin(0.1, 2.6, 0.1, 0.1, "cm")) 

#,legend.text=element_text(size=8) 
ggsave(file=paste0(output_dir, app , "_CS_sep_evol.svg"), width = 10, height = 6.5)










