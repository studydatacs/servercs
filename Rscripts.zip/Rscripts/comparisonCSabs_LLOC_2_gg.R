library(zoo)
library(xts)
#library(tsibble)
library(tseries)
library(ggplot2)
library(smooth)
library(strucchange)


#comparision CS absolute with LLOC 20x

#apps=c("phpmyadmin", "dokuwiki", "opencart", "phpbb", 
#       "phppgadmin","mediawiki", "prestashop","vanilla",
#       "dolibarr", "roundcubemail", "openemr", "kanboard")

#app
app="phpmyadmin"
app="dokuwiki";
app="opencart";
app="phpbb";
app="phppgadmin";
app="mediawiki";
app="prestashop";
app="vanilla";
app="dolibarr";
# app="roundcubemail";
# app="openemr";
# app="kanboard";

output_dir="D:/dwork/serversmells/analysis/compare_cs_absolute_LLOC/"

#path  ## abs or density
path= "D:/dwork/serversmells/resume/abs/"
file= paste(path ,"resume_", app , ".csv" , sep="")

#path= "D:/dwork/serversmells/resume/density/"
#file= paste(path ,"resume_", app , "_density.csv" , sep="")

dataCS =  read.csv(file,header=TRUE,sep=";")



path2= "D:/dwork/serversmells/resume/loc/"
file2= paste(path2,  app , "_loc.csv" , sep="")
dataM =  read.csv(file2,header=TRUE,sep=";")


cs = cbind.data.frame(date=as.Date(dataCS$Date, "%Y-%m-%d"),
                      totalCS = rowSums(dataCS[, 4:21] ),
                      meanCS =  rowMeans(dataCS[, 4:21] )
)

m = cbind.data.frame(date = as.Date(dataM$date, "%Y-%m-%d"),
                      kLLOC = as.numeric(dataM$Logical_Lines_of_Code_.LLOC.   )/1000,
                      kLOC = as.numeric(dataM$Lines_of_Code_.LOC. )/1000
)


#"Logical_Lines_of_Code_(LLOC)"


z_cs = zoo(cs$totalCS, cs$date)
x_cs = as.xts(z_cs)

z_m = zoo(m$kLLOC,m$date)
x_m = as.xts(z_m)

rx_cs=rollmean(x_cs, 10)
rx_m=rollmean(x_m, 10)

c=cor(rx_cs, rx_m)
clabel=paste0("cor ",round(c, 2))

coeff = 20/1000
csColor = "black"
mColor = "red"


names(rx_cs) = "cs"
names(rx_m) = "m"


ggplot()+    
  geom_line(data = rx_cs, aes(x = Index, y = cs  , color = csColor), size=2) +
  geom_line(data = rx_m, aes(x = Index, y = m / coeff ,color = mColor), size=2) +
  theme_minimal() +
  scale_y_continuous(
    name = "#CS",
    sec.axis = sec_axis(~.*coeff, name="kLLOC")
  ) +
  scale_x_date(date_breaks = "1 years", date_labels = "%Y")+
  theme(
    axis.title.y = element_text(color = csColor, size=13),
    axis.title.y.right = element_text(color = "black", size=13)
  ) +
  labs(title = app ) +
  annotate("text",  y= Inf, x =min(time(rx_cs)), label = paste0(clabel), vjust=1, hjust=0.25)+
#  scale_colour_identity() +
scale_colour_manual(name = 'legend', values =c(csColor, mColor), labels = c('#CS','kLLOC')) +
theme(legend.position="none", legend.box = "horizontal")
#theme(legend.position="bottom", legend.box = "horizontal")



ggsave(file=paste0(output_dir,app,".svg"), width=10, height=6.5)








