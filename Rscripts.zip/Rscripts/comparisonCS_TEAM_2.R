library(zoo)
library(xts)
#library(tsibble)
library(tseries)
library(ggplot2)
library(smooth)
library(strucchange)

apps=c("phpmyadmin", "dokuwiki", "opencart", "phpbb", 
       "phppgadmin","mediawiki", "prestashop","vanilla",
       "dolibarr", "roundcubemail", "openemr", "kanboard")
#app
app="phpmyadmin"
# app="dokuwiki";
# app="opencart";
# app="phpbb";
# app="phppgadmin";
# app="mediawiki";
# app="prestashop";
# app="vanilla";
# app="dolibarr";
# app="roundcubemail";
# app="openemr";
# app="kanboard";

#path  ## abs or density
# path= "D:/dwork/serversmells/resume/abs/"
# file= paste(path ,"resume_", app , ".csv" , sep="")

path= "D:/dwork/serversmells/resume/density/"
file= paste(path ,"resume_", app , "_density.csv" , sep="")

dataCS =  read.csv(file,header=TRUE,sep=";")


path2= "D:/dwork/data/commits/"
file2= paste(path2,  app , "_gitlog.csv" , sep="")
dataCOMM =  read.csv(file2,header=TRUE,sep=";")

dataCS <- dataCS[- 1, ]  #remove first line
dataCOMM= dataCOMM[-nrow(dataCOMM),] #remove last line

cs = cbind.data.frame(date=as.Date(dataCS$Date, "%Y-%m-%d"),
                      totalCS = rowSums(dataCS[, 4:21] ),
                      meanCS =  rowMeans(dataCS[, 4:21] )
)

#vage	num_commits	num_users	commits_per_user	commits_by_day

comm = cbind.data.frame(date=as.Date(dataCOMM$date2, "%Y-%m-%d"),
                        commits_per_user = as.numeric(dataCOMM$commits_per_user),
                        commits_by_day = as.numeric(dataCOMM$commits_by_day),
                        num_commits = as.numeric(dataCOMM$num_commits),
                        num_users = as.numeric(dataCOMM$num_users),
                        vage = as.numeric(dataCOMM$vage),
                        newusers=as.numeric(dataCOMM$newusers)
)


z_cs = zoo(cs$totalCS, cs$date)
x_cs = as.xts(z_cs)

z_comm = zoo(comm$newusers,comm$date)
x_comm = as.xts(z_comm)

c=cor(rollmean(x_cs, 10),rollmean(x_comm, 10))

#plot.new()
svg(paste0("d:/", app, ".svg"),width = 8, height = 7)
plot.xts(merge(rollmean(x_cs, 10), rollmean(x_comm, 10)),screens=c(1,2), main=app)
print(addLegend("top", legend.names = c("cs density", "new devs"), lty=c(1, 1), lwd=c(2, 2), col=c("black", "red")))

print(mtext(paste0("cor=", round(c,2)), side = 1 , line = 0, outer = FALSE))

dev.off() 
##graphics.off()

cat(paste(app,";",c, "\n"))








