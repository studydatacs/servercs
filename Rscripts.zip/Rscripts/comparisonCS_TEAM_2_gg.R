library(zoo)
library(xts)
#library(tsibble)
library(tseries)
library(ggplot2)
library(smooth)
library(strucchange)
library(ggrepel)

apps=c("phpmyadmin", "dokuwiki", "opencart", "phpbb", 
       "phppgadmin","mediawiki", "prestashop","vanilla",
       "dolibarr", "roundcubemail", "openemr", "kanboard")
#app
app="phpmyadmin"
# app="dokuwiki";
# app="opencart";
# app="phpbb";
# app="phppgadmin";
# app="mediawiki";
# app="prestashop";
# app="vanilla";
# app="dolibarr";
# app="roundcubemail";
# app="openemr";
# app="kanboard";

#path  ## abs or density
# path= "D:/dwork/serversmells/resume/abs/"
# file= paste(path ,"resume_", app , ".csv" , sep="")

path= "D:/dwork/serversmells/resume/density/"
file= paste(path ,"resume_", app , "_density.csv" , sep="")

dataCS =  read.csv(file,header=TRUE,sep=";")


path2= "D:/dwork/data/commits/"
file2= paste(path2,  app , "_gitlog.csv" , sep="")
dataCOMM =  read.csv(file2,header=TRUE,sep=";")

dataCS <- dataCS[- 1, ]  #remove first line
dataCOMM= dataCOMM[-nrow(dataCOMM),] #remove last line

cs = cbind.data.frame(date=as.Date(dataCS$Date, "%Y-%m-%d"),
                      totalCS = rowSums(dataCS[, 4:21] ),
                      meanCS =  rowMeans(dataCS[, 4:21] )
)

#vage	num_commits	num_users	commits_per_user	commits_by_day

comm = cbind.data.frame(date=as.Date(dataCOMM$date2, "%Y-%m-%d"),
                        commits_per_user = as.numeric(dataCOMM$commits_per_user),
                        commits_by_day = as.numeric(dataCOMM$commits_by_day),
                        num_commits = as.numeric(dataCOMM$num_commits),
                        num_users = as.numeric(dataCOMM$num_users),
                        vage = as.numeric(dataCOMM$vage),
                        newusers=as.numeric(dataCOMM$newusers)
)


z_cs = zoo(cs$totalCS, cs$date)
x_cs = as.xts(z_cs)

z_comm = zoo(comm$newusers,comm$date)
x_comm = as.xts(z_comm)

rx_cs=rollmean(x_cs, 10)
rx_comm=rollmean(x_comm, 10)

c=cor(rx_cs,rx_comm)

clabel=paste0("cor:",round(c, 2))

coeff = 1
csColor <- "#69b3a2"
commColor <- rgb(0.2, 0.6, 0.9, 1)

names(rx_cs) <- "cs"
names(rx_comm) <- "comm"
ggplot(data = rx_cs, aes(x = Index, y = cs ,color=csColor ))+    
  geom_line(,size=2) +
  geom_line(data = rx_comm, aes(x = Index, y = comm / coeff ,color=commColor), size=2) +
  theme_minimal() +
  scale_y_continuous(
    name = "CS Density kLLOC-1",
    sec.axis = sec_axis(~.*coeff, name="New Users")
  ) +
  scale_x_date(date_breaks = "1 years", date_labels = "%Y")+
  #theme_ipsum() +
  theme(
    axis.title.y = element_text(color = csColor, size=13),
    axis.title.y.right = element_text(color = commColor, size=13)
  ) +
  #geom_text(aes(x = as.Date("2010-01-01"), y = 15, label = "CS density")) + 
  #geom_text(aes(x = as.Date("2014-10-01"), y = 5, label = "New users")) +
  #geom_text(aes(x = as.Date("2014-10-01"), y = 20, label = clabel)) +
  #ggtitle(app)
  labs(title = app,
                  #subtitle = "Plot of length by dose",
                  #caption = clabel,
                  #           tag = clabel
       ) +
  annotate("text",  y= max(rx_cs$cs), x =mean(time(rx_cs)), label = clabel, vjust=1, hjust=1)+
  scale_colour_manual(name = 'legend', 
                      values =c(csColor, commColor), labels = c('CS Density','New Users'))


cat(paste(app,";",c, "\n"))











